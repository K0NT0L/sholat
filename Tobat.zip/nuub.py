#!/usr/bin/env python2

'''
# Jangan di recode bangsad! 
# Sumvah Ga guna! 
# Author star'-'
'''

import random
import os
import time
import sys


print ("\033[1;33m")
print ("_____________________________________")
print ("Make Tools ini Buat apa? ")
print
print (" 1. Pengen liat hasil coding bang Star:v")
print (" 2. Cuman Iseng kerna joned")
print (" 3. Kata-kata gua:v ")
print ("_____________________________________")
pri = input("\033[1;38mRoot@localHost =>> ") 

if pri == 1:
             time.sleep(0.1)
             print ("\033[1;33mThx ea para joned:( ")
             print ("\033[93mJangan Lupakan aing yeuh")
             exit()

if pri == 2:
             time.sleep(0.1)
             print "\033[1;35mLu kontol:V"
             print "eaea Joned =("
             exit()
          
if pri == 3:
           time.sleep(0.1)

while True:
           star = ("Upgrade muka biar kgaa joned")
           time.sleep(0.1)
           print "\033[1;34m%s"%(star)   
           
else:
             print ("\033[92mWrong Input!\033[00m")