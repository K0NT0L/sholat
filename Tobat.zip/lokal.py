#!/usr/bin/env python2 
#-*- coding: utf-8 -*-

import json
import os 
import time 
import sys
from urllib2 import urlopen


print ("\033[1;33mJadwal Sholat ")
print
dcok = raw_input("\033[00mMasukkan Kota => ") 
url = "https://time.siswadi.com/pray/?address='+dcok'"
dat = urlopen(url).read().decode("utf-8")
data = json.loads(dat)
 
print ("\033[31;1m")
print("\n\033[1;33m[\033[1;37m#\033[1;33m] \033[1;37mInformation >>>\033[00m")
print
print ("\033[1;33mSHUBUH >\033[37m"), str(data['data']['Fajr'])
print ("\033[1;37mDZUHUR >\033[37m"), str(data['data']['Dhuhr'])
print ("\033[1;30mASHAR >\033[37m"), str(data['data']['Asr'])
print ("\033[1;33mMAGHRIB >\033[37m"), str(data['data']['Maghrib'])
print ("\033[1;35mISYA' >\033[37m"), str(data['data']['Isha']) 
print 
print ("\033[00m")
os.system("exit")