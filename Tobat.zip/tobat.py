#!/usr/bin/env python2 

"""
# mau ngapain exploit nano? 
# heleh w nuub stah^_^
# hae
"""

sholat= """\033[97m
____  _           _       _
/ ___|| |__   ___ | | __ _| |_
\___ \| '_ \ / _ \| |/ _` | __|
 ___) | | | | (_) | | (_| | |_
|____/|_| |_|\___/|_|\__,_|\__|

\033[92mTools buat tobat gan^-^

\033[91mBerfaedah Banget ^~^

\033[00mAuthor : StarFuckTak

\033[97mVersion : \033[94m1.2

"""

import os 
import time 
import sys
 
os.system("clear") 

print sholat

print "\033[35;1m"
print("____________________________________")
print ("[ 1. ] Jadwal Sholat")
print ("[ 2. ] Help? ")
print ("[ 0. ] exit ")
print("____________________________________\033[00m")
time.sleep(1)

print

pilih = input("\033[00mRoot@localhost => ") 

if pilih == 1:
        time.sleep(0.1)
        os.system("python2 lokal.py")
        exit()

if pilih == 2:
        time.sleep(0.1)
        os.system("python2 nuub.py")
        exit()
        
if pilih == 0:
        os.system('clear')
        print ("Bye-Bye")
        print ("Assalamualaikum :)")
        time.sleep(2)
        exit()

else:
        print ("\033[1;33m")
        print ("wrong input")
        time.sleep(0.5)
        print ("Untuk Ulangin")
        print ("python2 tobat.py")
        print ("\033[00m")
        exit()
        